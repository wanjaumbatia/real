

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <div class="row d-flex justify-content-between">
                        <div class="col-4">
                            <?php echo e($user->name); ?>

                        </div>
                        <div class="col-4 text-end">
                            <a href="<?php echo e(route('admin.team.list')); ?>" class="btn-primary btn btn-sm">Back</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <form>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12 mt-2">
                                <div class="form-group">
                                    <label>Name:</label>
                                    <input hidden name="id" value="<?php echo e($user->id); ?>" />
                                    <input name="name" type="text" class="form-control" value="<?php echo e($user->name); ?>" />
                                </div>
                            </div>
                            <div class="col-12 mt-2">
                                <div class="form-group">
                                    <label>Phone Number:</label>
                                    <input name="phone" type="text" class="form-control" value="<?php echo e($user->phone); ?>" />
                                </div>
                            </div>
                            <div class="col-12 mt-2">
                                <div class="form-group">
                                    <label>Username:</label>
                                    <input name="username" type="text" class="form-control" value="<?php echo e($user->email); ?>" />
                                </div>
                            </div>
                            <div class="col-12 mt-2">
                                <div class="form-group">
                                    <label>Branch:</label>
                                    <input name="branch" type="text" class="form-control" value="<?php echo e($user->branch); ?>" />
                                </div>
                            </div>
                            <div class="col-12 mt-2">
                                <div class="form-group">
                                    <label>Role:</label>
                                    <select name="branch" class="form-control">
                                        <option>Sales Executiver</option>
                                        <option>Office Administrator</option>
                                        <option>Assistant Branch Manager</option>
                                        <option>Branch Manager</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 mt-2">
                                <div class="form-group">
                                    <label>Status:</label>
                                    <select name="active" class="form-control">
                                        <option>Active</option>
                                        <option>Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary mt-3 w-100">Update</button>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/admin/fieldteam/edit.blade.php ENDPATH**/ ?>