

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-6">
                            <?php echo e(__('Loans')); ?> 
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Customer</th>                                
                                <th>Amount</th>                            
                                <th>Interest Rate</th>
                                <th>Duration</th>
                                <th>Application Date</th>
                                <th>Sales Executive</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td>₦<?php echo e(number_format($item->amount)); ?></td>
                                <td><?php echo e($item->interest_percentage); ?></td>
                                <td><?php echo e($item->duration); ?> Months</td>
                                <td><?php echo e(date('d-m-Y', strtotime($item->application_date))); ?></td>                                
                                <td><?php echo e($item->handler); ?></td>
                                <td><?php echo e($item->status); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/loans/index.blade.php ENDPATH**/ ?>