

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-6">
                            <?php echo e(__('Total Branch Commisions')); ?> - <span style="font-weight: bold !important;">₦.<?php echo e(number_format($total,0)); ?></span>
                        </div>

                        <!-- <div class="col-4 text-end">
                            <?php echo e(__('Pending Loan Collection')); ?> - <span style="font-weight: bold !important;">₦.<?php echo e(number_format(1000,0)); ?></span>
                        </div> -->
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Sales Executive</th>
                                <th>Amount</th>
                                <th>Description</th>
                                <th>Branch</th>
                                <th>Approved</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $commissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->handler); ?></td>
                                <td>₦<?php echo e($item->amount); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <td><?php echo e($item->branch); ?></td>
                                <td>
                                    <?php if($item->approved == true): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Approved</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/office/commissions.blade.php ENDPATH**/ ?>