<?php echo e($slot); ?>

<?php /**PATH D:\Real_Laravel\api\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>