

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <div class="row d-flex justify-content-between">
                        <div class="col-4">
                            <?php echo e(__('Previous Target for Asaba')); ?>

                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(route('admin.targets.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <input hidden name="branch" value="<?php echo e($branch); ?>" />
                        <div class="form-group">
                            <label>Previous Target:</label>
                            <input type="number" disabled value="<?php echo e($prev_target); ?>" class="form-control" />
                        </div>
                        <div class="form-group mt-2">
                            <label>New Target:</label>
                            <input type="number" class="form-control" name="amount" />
                        </div>

                        <div class="form-group mt-3">
                            <button class="btn btn-primary w-100">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/operations/targets/create.blade.php ENDPATH**/ ?>