<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <form method="post" action="/import" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Import Users</label>
                                    <input required class="form-control" type="file" name="file" />
                                </div>
                                <button class="btn btn-primary w-100 mt-2">Upload</button>
                            </form>
                        </div>
                    </div>

                    <div class="card mt-3">
                        <div class="card-body">
                            <form method="post" action="/import_customers" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Import Customers</label>
                                    <input required class="form-control" type="file" name="file" />
                                </div>
                                <button class="btn btn-primary w-100 mt-2">Upload</button>
                            </form>
                        </div>
                    </div>

                    <div class="card mt-3">
                        <div class="card-body">
                            <form method="post" action="/import_loans" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Import Loans</label>
                                    <input required class="form-control" type="file" name="file" />
                                </div>
                                <button class="btn btn-primary w-100 mt-2">Upload</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/home.blade.php ENDPATH**/ ?>