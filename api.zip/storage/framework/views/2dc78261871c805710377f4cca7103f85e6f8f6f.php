

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <div class="row d-flex justify-content-between">
                        <div class="col-4">
                            <?php echo e(__('New Customer')); ?>

                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(route('customers.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" class="form-control" name="name" />
                        </div>

                        <div class="form-group mt-2">
                            <label for="phone">Phone Number</label>
                            <input type="text" class="form-control" name="phone" />
                        </div>

                        <div class="form-group mt-2">
                            <label for="town">Town</label>
                            <input type="text" class="form-control" name="town" />
                        </div>

                        <div class="form-group mt-2">
                            <label for="gender">Gender</label>
                            <input type="text" class="form-control" name="gender" />
                        </div>

                        <div class="form-group mt-2">
                            <label for="gender">Date of Birth</label>
                            <input type="date" class="form-control" name="dob" />
                        </div>

                        <div class="form-group mt-2">
                            <label for="gender">Address</label>
                            <input type="text" class="form-control" name="address" />
                        </div>
                        <div class="form-group mt-2">
                            <label for="gender">Type of Business</label>
                            <input type="text" class="form-control" name="business" />
                        </div>

                        <div class="form-group mt-2">
                            <label for="gender">Bank</label>
                            <input type="text" class="form-control" name="bank" />
                        </div>

                        <div class="form-group mt-2">
                            <label for="gender">Bank Account Number</label>
                            <input type="text" class="form-control" name="bank_acc" />
                        </div>

                        <div class="form-group mt-2">
                            <button class="btn btn-primary w-100">Create Customer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/customers/create.blade.php ENDPATH**/ ?>