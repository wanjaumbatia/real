

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <div class="row d-flex justify-content-between">
                        <div class="col-4">
                            Total Customers - <?php echo e(count($customers)); ?>

                        </div>
                        <?php if(Auth::user()->sales_executive==true): ?>
                        <div class="col-4 text-end">
                            <a href="/customers/create" class="btn btn-primary btn-sm">Create New</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Branch</th>
                                <th>Handler</th>
                                <th>Registered Date</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item['no']); ?></td>
                                <td><?php echo e($item['name']); ?></td>
                                <td><?php echo e($item['phone']); ?></td>
                                <td><?php echo e($item['branch']); ?></td>
                                <td><?php echo e($item['handler']); ?></td>                                
                                <td><?php echo e(date('d-m-Y', strtotime($item['created_by']))); ?></td>  
                                <td><a href="/customers/show/<?php echo e($item['id']); ?>" class="btn btn-primary btn-sm">Open</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($customers->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/customers/index.blade.php ENDPATH**/ ?>