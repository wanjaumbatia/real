

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <div class="row d-flex justify-content-between">
                        <div class="col-4">
                            Customer Details
                        </div>
                        <div class="col-6 text-end">
                            <a href="/customers/contribution/<?php echo e($customer->id); ?>" class="btn btn-primary btn-sm">New Payment</a>
                            <a class="btn btn-primary btn-sm">Make Payment</a>
                            <a class="btn btn-primary btn-sm">Request Loan</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(route('customers.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="name">Customer Number</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($customer->no); ?>" />
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="name">Full Name</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($customer->name); ?>" />
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <col-6 class="col-md-6 col-sm-12">
                                <div class="form-group mt-2">
                                    <label for="phone">Phone Number</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($customer->phone); ?>" />
                                </div>
                            </col-6>
                            <col-6 class="col-md-6 col-sm-12">
                                <div class="form-group mt-2">
                                    <label for="town">Town</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($customer->town); ?>" />
                                </div>
                            </col-6>
                        </div>

                        <div class="row">
                            <col-6 class="col-md-6 col-sm-12">
                                <div class="form-group mt-2">
                                    <label for="phone">Handler</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($customer->handler); ?>" />
                                </div>
                            </col-6>
                            <col-6 class="col-md-6 col-sm-12">
                                <div class="form-group mt-2">
                                    <label for="town">Branch</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($customer->branch); ?>" />
                                </div>
                            </col-6>
                        </div>

                        <div class="form-group mt-2">
                            <label for="gender">Address</label>
                            <input type="text" class="form-control" disabled value="<?php echo e($customer->address); ?>" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-9 mt-2">
            <div class="card">
                <div class="card-header">
                    <div class="row d-flex justify-content-between">
                        <div class="col-4">
                            Bank Accounts
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Bank Name</th>
                                <th>Bank Account Number</th>
                                <th>Branch</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $customer->bankaccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($item['bank_name']); ?></td>
                                <td><?php echo e($item['bank_account']); ?></td>
                                <td><?php echo e($item['bank_branch']); ?></td>
                                <td><?php echo e($item['bank_name']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>
                                <td align="center">No record founds!</td>
                            </p>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/customers/show.blade.php ENDPATH**/ ?>