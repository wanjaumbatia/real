<?php $__env->startComponent('mail::message'); ?>
    An account belonging to <?php echo e($handler); ?> who is a sales executive from <?php echo e($branch); ?> has just been reconciled by <?php echo e($user); ?> with a shortage of <?php echo e($short); ?>.
    Expected amount was <?php echo e($expected); ?> on <?php echo e(now()); ?>

<?php $__env->startComponent('mail::button', ['url'=>'www.google.com']); ?>
    View Report
<?php echo $__env->renderComponent(); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/shortage.blade.php ENDPATH**/ ?>