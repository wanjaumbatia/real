

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <div class="row d-flex justify-content-between">
                        <div class="col-4">
                            <?php echo e(__('Application Users')); ?>

                        </div>
                        <div class="col-4 text-end">
                            <a href="<?php echo e(route('admin.team.create')); ?>" class="btn-primary btn btn-sm">New User</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-striped">
                        <tr>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Phone</th>
                            <th>branch</th>
                            <th>Created On</th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e($item->phone); ?></td>
                            <td><?php echo e($item->branch); ?></td>
                            <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.team.edit' ,$item->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/admin/fieldteam/index.blade.php ENDPATH**/ ?>