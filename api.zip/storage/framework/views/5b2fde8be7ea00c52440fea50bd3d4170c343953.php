

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Reconcile Collection')); ?></span></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <form method="post" action="<?php echo e(route('office.disburse')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group ">
                            <input name="id" hidden value="<?php echo e($transaction->id); ?>" />
                            <label for="amount">Disbument Amount</label>
                            <input type="text" class="form-control" disabled value="₦.<?php echo e(number_format($transaction->credit,0)); ?>" />
                        </div>

                        <div class="form-group">
                            <button class="btn btn-primary w-100 my-2">Confirm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real_Laravel\api\resources\views/office/reconcile_withdrawal.blade.php ENDPATH**/ ?>